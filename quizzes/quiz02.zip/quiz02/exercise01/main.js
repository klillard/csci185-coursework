function showFox() {
    // your code here...
    document.querySelector("img").src = "images/fox.jpg"
    document.querySelector("p").innerHTML = "Fox"
    console.log('Change image and paragraph to fox...')
}

function showLion() {
    // your code here...
    document.querySelector("img").src = "images/lion.jpg"
    document.querySelector("p").innerHTML = "Lion"
    console.log('Change image and paragraph to lion...');
}

function showTiger() {
    // your code here...
    document.querySelector("img").src = "images/tiger.png"
    document.querySelector("p").innerHTML = "Tiger"
    console.log('Change image and paragraph to tiger...');
}

function showZebra() {
    // your code here...
    document.querySelector("p").innerHTML = "Zebra"
    document.querySelector("img").src = "images/zebra.jpg"
    console.log('Change image and paragraph to zebra...');
}

